﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BtnCheckServerPerformance = New System.Windows.Forms.Button()
        Me.BtnAddServer = New System.Windows.Forms.Button()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.BtnRemoveServer = New System.Windows.Forms.Button()
        Me.BtnExit = New System.Windows.Forms.Button()
        Me.lblServerNames = New System.Windows.Forms.Label()
        Me.txtServerInput = New System.Windows.Forms.TextBox()
        Me.lblAddRemoveServer = New System.Windows.Forms.Label()
        Me.BtnReadConfigFile = New System.Windows.Forms.Button()
        Me.txtReadConfigFile = New System.Windows.Forms.TextBox()
        Me.lblReadServerTextFile = New System.Windows.Forms.Label()
        Me.BtnClearText = New System.Windows.Forms.Button()
        Me.BtnCreateConfigFile = New System.Windows.Forms.Button()
        Me.txtCreateConfigFile = New System.Windows.Forms.TextBox()
        Me.txtDeleteFile = New System.Windows.Forms.TextBox()
        Me.BtnDeleteConfigFile = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'BtnCheckServerPerformance
        '
        Me.BtnCheckServerPerformance.Location = New System.Drawing.Point(62, 419)
        Me.BtnCheckServerPerformance.Name = "BtnCheckServerPerformance"
        Me.BtnCheckServerPerformance.Size = New System.Drawing.Size(153, 29)
        Me.BtnCheckServerPerformance.TabIndex = 0
        Me.BtnCheckServerPerformance.Text = "Check Server Performance"
        Me.BtnCheckServerPerformance.UseVisualStyleBackColor = True
        '
        'BtnAddServer
        '
        Me.BtnAddServer.Location = New System.Drawing.Point(575, 178)
        Me.BtnAddServer.Name = "BtnAddServer"
        Me.BtnAddServer.Size = New System.Drawing.Size(109, 23)
        Me.BtnAddServer.TabIndex = 1
        Me.BtnAddServer.Text = "Add Server"
        Me.BtnAddServer.UseVisualStyleBackColor = True
        '
        'ListBox1
        '
        Me.ListBox1.BackColor = System.Drawing.Color.LightBlue
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(62, 178)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(244, 212)
        Me.ListBox1.TabIndex = 3
        '
        'BtnRemoveServer
        '
        Me.BtnRemoveServer.Location = New System.Drawing.Point(575, 228)
        Me.BtnRemoveServer.Name = "BtnRemoveServer"
        Me.BtnRemoveServer.Size = New System.Drawing.Size(109, 23)
        Me.BtnRemoveServer.TabIndex = 4
        Me.BtnRemoveServer.Text = "Remove Server"
        Me.BtnRemoveServer.UseVisualStyleBackColor = True
        '
        'BtnExit
        '
        Me.BtnExit.BackColor = System.Drawing.Color.Red
        Me.BtnExit.Location = New System.Drawing.Point(442, 445)
        Me.BtnExit.Name = "BtnExit"
        Me.BtnExit.Size = New System.Drawing.Size(82, 35)
        Me.BtnExit.TabIndex = 5
        Me.BtnExit.Text = "Exit"
        Me.BtnExit.UseVisualStyleBackColor = False
        '
        'lblServerNames
        '
        Me.lblServerNames.AutoSize = True
        Me.lblServerNames.Location = New System.Drawing.Point(59, 147)
        Me.lblServerNames.Name = "lblServerNames"
        Me.lblServerNames.Size = New System.Drawing.Size(210, 13)
        Me.lblServerNames.TabIndex = 6
        Me.lblServerNames.Text = "Select Server to check server performance"
        '
        'txtServerInput
        '
        Me.txtServerInput.BackColor = System.Drawing.Color.LightBlue
        Me.txtServerInput.Location = New System.Drawing.Point(575, 123)
        Me.txtServerInput.Name = "txtServerInput"
        Me.txtServerInput.Size = New System.Drawing.Size(100, 20)
        Me.txtServerInput.TabIndex = 7
        '
        'lblAddRemoveServer
        '
        Me.lblAddRemoveServer.AutoSize = True
        Me.lblAddRemoveServer.Location = New System.Drawing.Point(423, 82)
        Me.lblAddRemoveServer.Name = "lblAddRemoveServer"
        Me.lblAddRemoveServer.Size = New System.Drawing.Size(425, 13)
        Me.lblAddRemoveServer.TabIndex = 8
        Me.lblAddRemoveServer.Text = "Type in Server Name to add server to list or select server from List Box to remov" &
    "e from list"
        '
        'BtnReadConfigFile
        '
        Me.BtnReadConfigFile.Location = New System.Drawing.Point(12, 93)
        Me.BtnReadConfigFile.Name = "BtnReadConfigFile"
        Me.BtnReadConfigFile.Size = New System.Drawing.Size(100, 23)
        Me.BtnReadConfigFile.TabIndex = 9
        Me.BtnReadConfigFile.Text = "Read Config File"
        Me.BtnReadConfigFile.UseVisualStyleBackColor = True
        '
        'txtReadConfigFile
        '
        Me.txtReadConfigFile.Location = New System.Drawing.Point(12, 63)
        Me.txtReadConfigFile.Name = "txtReadConfigFile"
        Me.txtReadConfigFile.Size = New System.Drawing.Size(100, 20)
        Me.txtReadConfigFile.TabIndex = 10
        Me.txtReadConfigFile.Text = "C:\ScanChart\uspiservers.txt"
        '
        'lblReadServerTextFile
        '
        Me.lblReadServerTextFile.AutoSize = True
        Me.lblReadServerTextFile.Location = New System.Drawing.Point(9, 36)
        Me.lblReadServerTextFile.Name = "lblReadServerTextFile"
        Me.lblReadServerTextFile.Size = New System.Drawing.Size(183, 13)
        Me.lblReadServerTextFile.TabIndex = 11
        Me.lblReadServerTextFile.Text = "Type in filename path"
        '
        'BtnClearText
        '
        Me.BtnClearText.Location = New System.Drawing.Point(442, 395)
        Me.BtnClearText.Name = "BtnClearText"
        Me.BtnClearText.Size = New System.Drawing.Size(82, 23)
        Me.BtnClearText.TabIndex = 12
        Me.BtnClearText.Text = "Clear Text"
        Me.BtnClearText.UseVisualStyleBackColor = True
        '
        'BtnCreateConfigFile
        '
        Me.BtnCreateConfigFile.Location = New System.Drawing.Point(130, 93)
        Me.BtnCreateConfigFile.Name = "BtnCreateConfigFile"
        Me.BtnCreateConfigFile.Size = New System.Drawing.Size(125, 24)
        Me.BtnCreateConfigFile.TabIndex = 13
        Me.BtnCreateConfigFile.Text = "Create Config File Path"
        Me.BtnCreateConfigFile.UseVisualStyleBackColor = True
        '
        'txtCreateConfigFile
        '
        Me.txtCreateConfigFile.Location = New System.Drawing.Point(130, 63)
        Me.txtCreateConfigFile.Name = "txtCreateConfigFile"
        Me.txtCreateConfigFile.Size = New System.Drawing.Size(125, 20)
        Me.txtCreateConfigFile.TabIndex = 14
        '
        'txtDeleteFile
        '
        Me.txtDeleteFile.Location = New System.Drawing.Point(280, 63)
        Me.txtDeleteFile.Name = "txtDeleteFile"
        Me.txtDeleteFile.Size = New System.Drawing.Size(100, 20)
        Me.txtDeleteFile.TabIndex = 15
        '
        'BtnDeleteConfigFile
        '
        Me.BtnDeleteConfigFile.Location = New System.Drawing.Point(280, 92)
        Me.BtnDeleteConfigFile.Name = "BtnDeleteConfigFile"
        Me.BtnDeleteConfigFile.Size = New System.Drawing.Size(100, 25)
        Me.BtnDeleteConfigFile.TabIndex = 16
        Me.BtnDeleteConfigFile.Text = "Delete Config File"
        Me.BtnDeleteConfigFile.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(922, 492)
        Me.Controls.Add(Me.BtnDeleteConfigFile)
        Me.Controls.Add(Me.txtDeleteFile)
        Me.Controls.Add(Me.txtCreateConfigFile)
        Me.Controls.Add(Me.BtnCreateConfigFile)
        Me.Controls.Add(Me.BtnClearText)
        Me.Controls.Add(Me.lblReadServerTextFile)
        Me.Controls.Add(Me.txtReadConfigFile)
        Me.Controls.Add(Me.BtnReadConfigFile)
        Me.Controls.Add(Me.lblAddRemoveServer)
        Me.Controls.Add(Me.txtServerInput)
        Me.Controls.Add(Me.lblServerNames)
        Me.Controls.Add(Me.BtnExit)
        Me.Controls.Add(Me.BtnRemoveServer)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.BtnAddServer)
        Me.Controls.Add(Me.BtnCheckServerPerformance)
        Me.Name = "Form1"
        Me.Text = "Application Server Peformance Check"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BtnCheckServerPerformance As Button
    Friend WithEvents BtnAddServer As Button
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents BtnRemoveServer As Button
    Friend WithEvents BtnExit As Button
    Friend WithEvents lblServerNames As Label
    Friend WithEvents txtServerInput As TextBox
    Friend WithEvents lblAddRemoveServer As Label
    Friend WithEvents BtnReadConfigFile As Button
    Friend WithEvents txtReadConfigFile As TextBox
    Friend WithEvents lblReadServerTextFile As Label
    Friend WithEvents BtnClearText As Button
    Friend WithEvents BtnCreateConfigFile As Button
    Friend WithEvents txtCreateConfigFile As TextBox
    Friend WithEvents txtDeleteFile As TextBox
    Friend WithEvents BtnDeleteConfigFile As Button
End Class
