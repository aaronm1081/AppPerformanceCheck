﻿Imports System.Security
Imports System.Data.SqlClient
Imports System.IO
Imports System.Text
Imports System
Imports System.Management

Public Class Form2
    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles BtnExit.Click
        Close()
    End Sub
    ''Close Form

    Private Sub BtnEndPrintHost_Click(sender As Object, e As EventArgs) Handles BtnEndPrintHost.Click
        ''Ends Print Host on Server Based on Form Name

        Try
            My.Computer.Network.Ping(txtEndHostServer.Text)
            MessageBox.Show("Connected")

            Dim p As Process
            For Each p In System.Diagnostics.Process.GetProcessesByName("\\" + txtEndHostServer.Text + "\c$\windows\splwow64.exe")
                p.Kill()
                p.WaitForExit()
                If p.HasExited Then
                    MessageBox.Show("Process Ended")
                End If
            Next
        Catch ex As Exception
            MessageBox.Show("Not Connected")
        End Try
    End Sub

    Private Sub BtnCheckPrintMasterStatus_Click(sender As Object, e As EventArgs) Handles BtnCheckPrintMasterStatus.Click

        Dim databaseItem As String


        For Each databaseItem In ListBox1.Items

            Try
                Dim connectionString As String = "Server=" + txtSQLInstance.Text + ";Database=" + databaseItem + ";User ID=" + txtUserID.Text + ";Password=" + txtPassword.Text + ";"
                Using connection As New SqlConnection(connectionString)
                    Dim command As New SqlCommand("Select [status] From [" + databaseItem + "].dbo.PrintMaster where [status] Not in ('Completed', 'Cancelled')", connection)

                    command.Connection.Open()
                    If (connection.State = ConnectionState.Open) Then

                        txtPrintMasterResults.AppendText(databaseItem + " Connected" + vbNewLine)

                    End If
                    Try
                        Dim reader As SqlDataReader = command.ExecuteReader()
                        Dim dt As New DataTable()
                        dt.Load(reader)

                        For Each row As DataRow In dt.Rows
                            txtPrintMasterResults.AppendText(row("status").ToString() + vbNewLine)
                        Next
                    Catch ex As Exception
                        txtPrintMasterResults.AppendText("No running print jobs for " + databaseItem + " " + vbNewLine)
                    End Try
                End Using

            Catch ex As Exception
                txtPrintMasterResults.AppendText(databaseItem + " not connected or not in " + txtSQLInstance.Text + vbNewLine)

            End Try

        Next
        MessageBox.Show("PrintMaster Checked")

    End Sub

    Private Sub BtnClearPrintMaster_Click(sender As Object, e As EventArgs) Handles BtnClearPrintMaster.Click

        Dim databaseItem As String


        For Each databaseItem In ListBox1.Items

            Try
                Dim connectionString As String = "Server=" + txtSQLInstance.Text + ";Database=" + databaseItem + ";User ID=" + txtUserID.Text + ";Password=" + txtPassword.Text + ";"
                Using connection As New SqlConnection(connectionString)
                    Dim command As New SqlCommand("Update [" + databaseItem + "].dbo.PrintMaster set [status] = 'Cancelled' where [status] not in ('Completed', 'Cancelled')", connection)

                    command.Connection.Open()
                    If (connection.State = ConnectionState.Open) Then

                        txtPrintMasterResults.AppendText(databaseItem + " Connected" + vbNewLine)

                    End If
                    Try
                        txtPrintMasterResults.AppendText(command.ExecuteNonQuery().ToString() + vbNewLine)

                    Catch ex As Exception
                        ''txtPrintMasterResults.AppendText("No running print jobs for " + databaseItem + " " + vbNewLine)
                    End Try
                End Using

            Catch ex As Exception
                txtPrintMasterResults.AppendText(databaseItem + " not connected or not in " + txtSQLInstance.Text + vbNewLine)

            End Try

        Next
        MessageBox.Show("PrintMaster Cleared")

    End Sub

    Private Sub BtnRemoveDatabase_Click(sender As Object, e As EventArgs) Handles BtnRemoveDatabase.Click
        ''Removes Database
        If ListBox1.SelectedIndex > -1 Then
            ListBox1.Items.RemoveAt(ListBox1.SelectedIndex)
        ElseIf txtDatabaseName.Text IsNot String.Empty Then
            ListBox1.Items.Remove(txtDatabaseName.Text)
        Else
            MessageBox.Show("Please type in or select Server Name to Remove Server")
        End If
    End Sub

    Private Sub BtnAddDatabase_Click(sender As Object, e As EventArgs) Handles BtnAddDatabase.Click
        ''Adds Database
        If txtDatabaseName.Text Is String.Empty = False Then
            ListBox1.Items.Add(txtDatabaseName.Text)
        ElseIf txtDatabaseName.Text Is String.Empty And txtTextList.Text Is String.Empty = False Then
            ListBox1.Items.AddRange(txtTextList.Lines())
        End If

    End Sub

    Private Sub BtnReadConfigFile_Click(sender As Object, e As EventArgs) Handles BtnReadConfigFile.Click
        Try
            Dim lines() As String = IO.File.ReadAllLines(txtConfigFilePath.Text)
            ListBox1.Items.AddRange(lines)
        Catch ex As Exception
            MessageBox.Show("Path does not exist or extension not added to the end of the file name")
        End Try

    End Sub

    Private Sub BtnClearText_Click(sender As Object, e As EventArgs) Handles BtnClearText.Click
        ListBox1.Items.Clear()
        txtPrintMasterResults.Clear()
        txtDatabaseName.Clear()
        txtLocalStorageResults.Clear()
        MessageBox.Show("All Text have cleared.")
        txtConfigFilePath.Text = "C:\ScanChart\" + Me.Text + ".txt"
    End Sub

    Private Sub BtnCheckLocalStorage_Click(sender As Object, e As EventArgs) Handles BtnCheckLocalStorage.Click
        Dim path As String = txtLocalStoragePath.Text
        Dim acronym As String
        Dim pathLines() As String = IO.File.ReadAllLines(path)
        '' Dim databaseName As String
        Dim arrayItems() As String
        ReDim arrayItems(ListBox1.Items.Count())

        ListBox1.Items.CopyTo(arrayItems, 0)

        For i As Integer = 1 To ListBox1.Items.Count()

            arrayItems(i - 1) = ListBox1.Items(i - 1).ToString()
            Try
                For Each p In pathLines
                    acronym = arrayItems(i - 1).Replace("ScanChart-", "")
                    If p.Contains(acronym) Then
                        txtLocalStorageResults.AppendText(p + vbNewLine)
                    ElseIf p.ToUpper().Contains(acronym) Then
                        txtLocalStorageResults.AppendText(p + vbNewLine)
                    End If

                Next
            Catch ex As Exception

                MessageBox.Show("DatabaseName acronym not found in C:\ScanChart\LocalStorageLocations.txt")
            End Try
        Next i
        txtLocalStorageResults.AppendText(txtLocalStorageResults.Lines.Count() - 1.ToString())

    End Sub

    Private Sub BtnCreateConfigFile_Click(sender As Object, e As EventArgs) Handles BtnCreateConfigFile.Click
        Try

            Dim path As String = txtCreateConfigFile.Text

            Dim arrayItems() As String
            ReDim arrayItems(ListBox1.Items.Count() - 1)
            If File.Exists(path) Then
                File.Delete(path)
            End If
            For i = 1 To ListBox1.Items.Count()
                arrayItems(i - 1) = ListBox1.Items(i - 1).ToString()
                File.AppendAllText(path, arrayItems(i - 1).ToString() + vbNewLine)

            Next i

            MessageBox.Show("File has been created")
        Catch ex As Exception
            MessageBox.Show("File not created")
        End Try

    End Sub


    'Private Sub BtnCheckPrinterSettings_Click(sender As Object, e As EventArgs) Handles BtnCheckPrinterSettings.Click
    '    Dim objSettings As New Printing.PrinterSettings
    '    Dim printerName As String
    '    Dim options As ConnectionOptions
    '    Dim query As ObjectQuery = New ObjectQuery("select * from Win32_OperatingSystem")
    '    Dim searcher As ManagementObjectSearcher = New ManagementObjectSearcher(query)
    '    Dim queryCollection As ManagementObjectCollection = searcher.Get()
    '    Dim scope As ManagementScope
    '    Dim path As ManagementPath
    '    path = New ManagementPath("\\" + txtPrinterServer.Text.ToString() + "\root\cimv2")
    '    options = New ConnectionOptions
    '    options.Username = txtUserID.Text
    '    options.Password = txtPassword.Text
    '    scope = New ManagementScope(path, options)
    '    scope.Connect()
    '    For Each printer As ManagementObject In queryCollection
    '        Dim pdc As System.Management.PropertyDataCollection = printer.Properties
    '        For Each pd As System.Management.PropertyData In pdc

    '            printer.Scope.Connect()
    '            txtPrinterrSettings.AppendText(pd.Value.ToString() + vbNewLine)
    '        Next

    '        printerName = printer("Name").ToString().ToLower()
    '        txtPrinterrSettings.AppendText("Printer =" + printerName)
    '        '' txtPrinterrSettings.AppendText(printer.GetPropertyValue("Duplex"))

    '    Next

    '    'For i As Integer = 0 To Printing.PrinterSettings.InstalledPrinters.Count() - 1
    '    '    Try
    '    '        For Each strPrinter In Printing.PrinterSettings.InstalledPrinters
    '    '            txtPrinterrSettings.AppendText(strPrinter)
    '    '        Next
    '    '    Catch ex As Exception

    '    '    End Try
    '    'Next i
    'End Sub


End Class