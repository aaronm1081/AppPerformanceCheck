﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.BtnAddDatabase = New System.Windows.Forms.Button()
        Me.BtnRemoveDatabase = New System.Windows.Forms.Button()
        Me.lblPrintMasterStatus = New System.Windows.Forms.Label()
        Me.lblLocalStorageCheck = New System.Windows.Forms.Label()
        Me.lblAffectedObjects = New System.Windows.Forms.Label()
        Me.BtnEndPrintHost = New System.Windows.Forms.Button()
        Me.BtnCheckPrintMasterStatus = New System.Windows.Forms.Button()
        Me.BtnClearPrintMaster = New System.Windows.Forms.Button()
        Me.BtnCheckLocalStorage = New System.Windows.Forms.Button()
        Me.BtnExit = New System.Windows.Forms.Button()
        Me.lblDatabaseName = New System.Windows.Forms.Label()
        Me.txtPrintMasterResults = New System.Windows.Forms.TextBox()
        Me.lblDatabaseList = New System.Windows.Forms.Label()
        Me.BtnReadConfigFile = New System.Windows.Forms.Button()
        Me.BtnClearText = New System.Windows.Forms.Button()
        Me.txtConfigFilePath = New System.Windows.Forms.TextBox()
        Me.lblConfigFilePath = New System.Windows.Forms.Label()
        Me.txtLocalStorageResults = New System.Windows.Forms.TextBox()
        Me.txtCreateConfigFile = New System.Windows.Forms.TextBox()
        Me.txtDatabaseName = New System.Windows.Forms.TextBox()
        Me.BtnCreateConfigFile = New System.Windows.Forms.Button()
        Me.txtTextList = New System.Windows.Forms.TextBox()
        Me.txtSQLInstance = New System.Windows.Forms.TextBox()
        Me.txtUserID = New System.Windows.Forms.TextBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.lblCredentials = New System.Windows.Forms.Label()
        Me.lblUserID = New System.Windows.Forms.Label()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.txtLocalStoragePath = New System.Windows.Forms.TextBox()
        Me.lblCopyListofDatabases = New System.Windows.Forms.Label()
        Me.txtEndHostServer = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(39, 137)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(224, 212)
        Me.ListBox1.TabIndex = 0
        '
        'BtnAddDatabase
        '
        Me.BtnAddDatabase.Location = New System.Drawing.Point(76, 447)
        Me.BtnAddDatabase.Name = "BtnAddDatabase"
        Me.BtnAddDatabase.Size = New System.Drawing.Size(108, 23)
        Me.BtnAddDatabase.TabIndex = 1
        Me.BtnAddDatabase.Text = "Add Database"
        Me.BtnAddDatabase.UseVisualStyleBackColor = True
        '
        'BtnRemoveDatabase
        '
        Me.BtnRemoveDatabase.Location = New System.Drawing.Point(76, 484)
        Me.BtnRemoveDatabase.Name = "BtnRemoveDatabase"
        Me.BtnRemoveDatabase.Size = New System.Drawing.Size(108, 23)
        Me.BtnRemoveDatabase.TabIndex = 2
        Me.BtnRemoveDatabase.Text = "Remove Database"
        Me.BtnRemoveDatabase.UseVisualStyleBackColor = True
        '
        'lblPrintMasterStatus
        '
        Me.lblPrintMasterStatus.AutoSize = True
        Me.lblPrintMasterStatus.Location = New System.Drawing.Point(1044, 29)
        Me.lblPrintMasterStatus.Name = "lblPrintMasterStatus"
        Me.lblPrintMasterStatus.Size = New System.Drawing.Size(93, 13)
        Me.lblPrintMasterStatus.TabIndex = 3
        Me.lblPrintMasterStatus.Text = "PrintMaster Status"
        '
        'lblLocalStorageCheck
        '
        Me.lblLocalStorageCheck.AutoSize = True
        Me.lblLocalStorageCheck.Location = New System.Drawing.Point(1044, 228)
        Me.lblLocalStorageCheck.Name = "lblLocalStorageCheck"
        Me.lblLocalStorageCheck.Size = New System.Drawing.Size(107, 13)
        Me.lblLocalStorageCheck.TabIndex = 4
        Me.lblLocalStorageCheck.Text = "Local Storage Check"
        '
        'lblAffectedObjects
        '
        Me.lblAffectedObjects.AutoSize = True
        Me.lblAffectedObjects.Location = New System.Drawing.Point(609, 18)
        Me.lblAffectedObjects.Name = "lblAffectedObjects"
        Me.lblAffectedObjects.Size = New System.Drawing.Size(86, 13)
        Me.lblAffectedObjects.TabIndex = 8
        Me.lblAffectedObjects.Text = "Affected Objects"
        '
        'BtnEndPrintHost
        '
        Me.BtnEndPrintHost.BackColor = System.Drawing.Color.PaleVioletRed
        Me.BtnEndPrintHost.Location = New System.Drawing.Point(539, 536)
        Me.BtnEndPrintHost.Name = "BtnEndPrintHost"
        Me.BtnEndPrintHost.Size = New System.Drawing.Size(105, 40)
        Me.BtnEndPrintHost.TabIndex = 9
        Me.BtnEndPrintHost.Text = "End Print Host"
        Me.BtnEndPrintHost.UseVisualStyleBackColor = False
        '
        'BtnCheckPrintMasterStatus
        '
        Me.BtnCheckPrintMasterStatus.Location = New System.Drawing.Point(994, 73)
        Me.BtnCheckPrintMasterStatus.Name = "BtnCheckPrintMasterStatus"
        Me.BtnCheckPrintMasterStatus.Size = New System.Drawing.Size(91, 34)
        Me.BtnCheckPrintMasterStatus.TabIndex = 10
        Me.BtnCheckPrintMasterStatus.Text = "Check PrintMaster"
        Me.BtnCheckPrintMasterStatus.UseVisualStyleBackColor = True
        '
        'BtnClearPrintMaster
        '
        Me.BtnClearPrintMaster.Location = New System.Drawing.Point(1113, 73)
        Me.BtnClearPrintMaster.Name = "BtnClearPrintMaster"
        Me.BtnClearPrintMaster.Size = New System.Drawing.Size(85, 34)
        Me.BtnClearPrintMaster.TabIndex = 11
        Me.BtnClearPrintMaster.Text = "Clear PrintMaster"
        Me.BtnClearPrintMaster.UseVisualStyleBackColor = True
        '
        'BtnCheckLocalStorage
        '
        Me.BtnCheckLocalStorage.Location = New System.Drawing.Point(1046, 279)
        Me.BtnCheckLocalStorage.Name = "BtnCheckLocalStorage"
        Me.BtnCheckLocalStorage.Size = New System.Drawing.Size(91, 35)
        Me.BtnCheckLocalStorage.TabIndex = 12
        Me.BtnCheckLocalStorage.Text = "Check Local Storage"
        Me.BtnCheckLocalStorage.UseVisualStyleBackColor = True
        '
        'BtnExit
        '
        Me.BtnExit.BackColor = System.Drawing.Color.Red
        Me.BtnExit.Location = New System.Drawing.Point(612, 598)
        Me.BtnExit.Name = "BtnExit"
        Me.BtnExit.Size = New System.Drawing.Size(105, 34)
        Me.BtnExit.TabIndex = 15
        Me.BtnExit.Text = "Exit"
        Me.BtnExit.UseVisualStyleBackColor = False
        '
        'lblDatabaseName
        '
        Me.lblDatabaseName.AutoSize = True
        Me.lblDatabaseName.Location = New System.Drawing.Point(88, 371)
        Me.lblDatabaseName.Name = "lblDatabaseName"
        Me.lblDatabaseName.Size = New System.Drawing.Size(84, 13)
        Me.lblDatabaseName.TabIndex = 16
        Me.lblDatabaseName.Text = "Database Name"
        '
        'txtPrintMasterResults
        '
        Me.txtPrintMasterResults.Location = New System.Drawing.Point(368, 43)
        Me.txtPrintMasterResults.Multiline = True
        Me.txtPrintMasterResults.Name = "txtPrintMasterResults"
        Me.txtPrintMasterResults.Size = New System.Drawing.Size(556, 128)
        Me.txtPrintMasterResults.TabIndex = 18
        '
        'lblDatabaseList
        '
        Me.lblDatabaseList.AutoSize = True
        Me.lblDatabaseList.Location = New System.Drawing.Point(75, 121)
        Me.lblDatabaseList.Name = "lblDatabaseList"
        Me.lblDatabaseList.Size = New System.Drawing.Size(72, 13)
        Me.lblDatabaseList.TabIndex = 21
        Me.lblDatabaseList.Text = "Database List"
        '
        'BtnReadConfigFile
        '
        Me.BtnReadConfigFile.Location = New System.Drawing.Point(12, 79)
        Me.BtnReadConfigFile.Name = "BtnReadConfigFile"
        Me.BtnReadConfigFile.Size = New System.Drawing.Size(104, 23)
        Me.BtnReadConfigFile.TabIndex = 30
        Me.BtnReadConfigFile.Text = "Read Config File"
        Me.BtnReadConfigFile.UseVisualStyleBackColor = True
        '
        'BtnClearText
        '
        Me.BtnClearText.Location = New System.Drawing.Point(687, 536)
        Me.BtnClearText.Name = "BtnClearText"
        Me.BtnClearText.Size = New System.Drawing.Size(87, 40)
        Me.BtnClearText.TabIndex = 31
        Me.BtnClearText.Text = "Clear Text"
        Me.BtnClearText.UseVisualStyleBackColor = True
        '
        'txtConfigFilePath
        '
        Me.txtConfigFilePath.Location = New System.Drawing.Point(12, 53)
        Me.txtConfigFilePath.Name = "txtConfigFilePath"
        Me.txtConfigFilePath.Size = New System.Drawing.Size(123, 20)
        Me.txtConfigFilePath.TabIndex = 32
        Me.txtConfigFilePath.Text = "C:\ScanChart\"
        '
        'lblConfigFilePath
        '
        Me.lblConfigFilePath.AutoSize = True
        Me.lblConfigFilePath.Location = New System.Drawing.Point(36, 18)
        Me.lblConfigFilePath.Name = "lblConfigFilePath"
        Me.lblConfigFilePath.Size = New System.Drawing.Size(258, 13)
        Me.lblConfigFilePath.TabIndex = 33
        Me.lblConfigFilePath.Text = "Type in Config File Path or use default path in textbox"
        '
        'txtLocalStorageResults
        '
        Me.txtLocalStorageResults.Location = New System.Drawing.Point(368, 200)
        Me.txtLocalStorageResults.Multiline = True
        Me.txtLocalStorageResults.Name = "txtLocalStorageResults"
        Me.txtLocalStorageResults.Size = New System.Drawing.Size(556, 146)
        Me.txtLocalStorageResults.TabIndex = 22
        '
        'txtCreateConfigFile
        '
        Me.txtCreateConfigFile.Location = New System.Drawing.Point(163, 53)
        Me.txtCreateConfigFile.Name = "txtCreateConfigFile"
        Me.txtCreateConfigFile.Size = New System.Drawing.Size(110, 20)
        Me.txtCreateConfigFile.TabIndex = 39
        '
        'txtDatabaseName
        '
        Me.txtDatabaseName.Location = New System.Drawing.Point(66, 409)
        Me.txtDatabaseName.Name = "txtDatabaseName"
        Me.txtDatabaseName.Size = New System.Drawing.Size(132, 20)
        Me.txtDatabaseName.TabIndex = 37
        '
        'BtnCreateConfigFile
        '
        Me.BtnCreateConfigFile.Location = New System.Drawing.Point(163, 79)
        Me.BtnCreateConfigFile.Name = "BtnCreateConfigFile"
        Me.BtnCreateConfigFile.Size = New System.Drawing.Size(110, 23)
        Me.BtnCreateConfigFile.TabIndex = 38
        Me.BtnCreateConfigFile.Text = "Create Config File"
        Me.BtnCreateConfigFile.UseVisualStyleBackColor = True
        '
        'txtTextList
        '
        Me.txtTextList.Location = New System.Drawing.Point(42, 553)
        Me.txtTextList.Multiline = True
        Me.txtTextList.Name = "txtTextList"
        Me.txtTextList.Size = New System.Drawing.Size(252, 96)
        Me.txtTextList.TabIndex = 40
        '
        'txtSQLInstance
        '
        Me.txtSQLInstance.Location = New System.Drawing.Point(984, 500)
        Me.txtSQLInstance.Name = "txtSQLInstance"
        Me.txtSQLInstance.Size = New System.Drawing.Size(188, 20)
        Me.txtSQLInstance.TabIndex = 42
        Me.txtSQLInstance.Text = "TXUSPIPSS084"
        '
        'txtUserID
        '
        Me.txtUserID.Location = New System.Drawing.Point(984, 557)
        Me.txtUserID.Name = "txtUserID"
        Me.txtUserID.Size = New System.Drawing.Size(100, 20)
        Me.txtUserID.TabIndex = 43
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(984, 606)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(100, 20)
        Me.txtPassword.TabIndex = 44
        '
        'lblCredentials
        '
        Me.lblCredentials.AutoSize = True
        Me.lblCredentials.Location = New System.Drawing.Point(911, 471)
        Me.lblCredentials.Name = "lblCredentials"
        Me.lblCredentials.Size = New System.Drawing.Size(316, 13)
        Me.lblCredentials.TabIndex = 45
        Me.lblCredentials.Text = "Please enter SQL Credentials below and type in the SQL instance"
        '
        'lblUserID
        '
        Me.lblUserID.AutoSize = True
        Me.lblUserID.Location = New System.Drawing.Point(984, 541)
        Me.lblUserID.Name = "lblUserID"
        Me.lblUserID.Size = New System.Drawing.Size(40, 13)
        Me.lblUserID.TabIndex = 46
        Me.lblUserID.Text = "UserID"
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.Location = New System.Drawing.Point(984, 590)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(53, 13)
        Me.lblPassword.TabIndex = 47
        Me.lblPassword.Text = "Password"
        '
        'txtLocalStoragePath
        '
        Me.txtLocalStoragePath.Location = New System.Drawing.Point(996, 246)
        Me.txtLocalStoragePath.Name = "txtLocalStoragePath"
        Me.txtLocalStoragePath.Size = New System.Drawing.Size(202, 20)
        Me.txtLocalStoragePath.TabIndex = 49
        Me.txtLocalStoragePath.Text = "C:\ScanChart\LocalStorageLocations.txt"
        '
        'lblCopyListofDatabases
        '
        Me.lblCopyListofDatabases.AutoSize = True
        Me.lblCopyListofDatabases.Location = New System.Drawing.Point(39, 517)
        Me.lblCopyListofDatabases.Name = "lblCopyListofDatabases"
        Me.lblCopyListofDatabases.Size = New System.Drawing.Size(265, 13)
        Me.lblCopyListofDatabases.TabIndex = 50
        Me.lblCopyListofDatabases.Text = "Copy your list of Databases here. Must be listed in lines"
        '
        'txtEndHostServer
        '
        Me.txtEndHostServer.Location = New System.Drawing.Point(550, 463)
        Me.txtEndHostServer.Name = "txtEndHostServer"
        Me.txtEndHostServer.Size = New System.Drawing.Size(213, 20)
        Me.txtEndHostServer.TabIndex = 51
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1239, 661)
        Me.Controls.Add(Me.txtEndHostServer)
        Me.Controls.Add(Me.lblCopyListofDatabases)
        Me.Controls.Add(Me.txtLocalStoragePath)
        Me.Controls.Add(Me.lblPassword)
        Me.Controls.Add(Me.lblUserID)
        Me.Controls.Add(Me.lblCredentials)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.txtUserID)
        Me.Controls.Add(Me.txtSQLInstance)
        Me.Controls.Add(Me.txtTextList)
        Me.Controls.Add(Me.BtnCreateConfigFile)
        Me.Controls.Add(Me.txtDatabaseName)
        Me.Controls.Add(Me.txtCreateConfigFile)
        Me.Controls.Add(Me.lblConfigFilePath)
        Me.Controls.Add(Me.txtConfigFilePath)
        Me.Controls.Add(Me.BtnClearText)
        Me.Controls.Add(Me.BtnReadConfigFile)
        Me.Controls.Add(Me.txtLocalStorageResults)
        Me.Controls.Add(Me.lblDatabaseList)
        Me.Controls.Add(Me.txtPrintMasterResults)
        Me.Controls.Add(Me.lblDatabaseName)
        Me.Controls.Add(Me.BtnExit)
        Me.Controls.Add(Me.BtnCheckLocalStorage)
        Me.Controls.Add(Me.BtnClearPrintMaster)
        Me.Controls.Add(Me.BtnCheckPrintMasterStatus)
        Me.Controls.Add(Me.BtnEndPrintHost)
        Me.Controls.Add(Me.lblAffectedObjects)
        Me.Controls.Add(Me.lblLocalStorageCheck)
        Me.Controls.Add(Me.lblPrintMasterStatus)
        Me.Controls.Add(Me.BtnRemoveDatabase)
        Me.Controls.Add(Me.BtnAddDatabase)
        Me.Controls.Add(Me.ListBox1)
        Me.Name = "Form2"
        Me.Text = "Performance Check Page"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents BtnAddDatabase As Button
    Friend WithEvents BtnRemoveDatabase As Button
    Friend WithEvents lblPrintMasterStatus As Label
    Friend WithEvents lblLocalStorageCheck As Label
    Friend WithEvents lblAffectedObjects As Label
    Friend WithEvents BtnEndPrintHost As Button
    Friend WithEvents BtnCheckPrintMasterStatus As Button
    Friend WithEvents BtnClearPrintMaster As Button
    Friend WithEvents BtnCheckLocalStorage As Button
    Friend WithEvents BtnExit As Button
    Friend WithEvents lblDatabaseName As Label
    Friend WithEvents txtPrintMasterResults As TextBox
    Friend WithEvents lblDatabaseList As Label
    Friend WithEvents BtnReadConfigFile As Button
    Friend WithEvents BtnClearText As Button
    Friend WithEvents txtConfigFilePath As TextBox
    Friend WithEvents lblConfigFilePath As Label
    Friend WithEvents txtLocalStorageResults As TextBox
    Friend WithEvents txtCreateConfigFile As TextBox
    Friend WithEvents txtDatabaseName As TextBox
    Friend WithEvents BtnCreateConfigFile As Button
    Friend WithEvents txtTextList As TextBox
    Friend WithEvents txtSQLInstance As TextBox
    Friend WithEvents txtUserID As TextBox
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents lblCredentials As Label
    Friend WithEvents lblUserID As Label
    Friend WithEvents lblPassword As Label
    Friend WithEvents txtLocalStoragePath As TextBox
    Friend WithEvents lblCopyListofDatabases As Label
    Friend WithEvents txtEndHostServer As TextBox
End Class
