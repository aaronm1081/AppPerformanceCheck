﻿Imports System.IO
Imports System.Text
Public Class Form1
    Private Sub BtnCheckServerPerformance_Click(sender As Object, e As EventArgs) Handles BtnCheckServerPerformance.Click
        Try
            If ListBox1.SelectedIndex = -1 Then
                MessageBox.Show("Select a Server")

            End If

            If ListBox1.SelectedIndex > -1 Then
                Form2.Show()
                Form2.Text = ListBox1.SelectedItem.ToString()
                Form2.txtEndHostServer.Text = ListBox1.SelectedItem.ToString()
                Dim path As String = "c:\ScanChart\" + ListBox1.SelectedItem.ToString() + ".txt"
                Form2.txtConfigFilePath.Text = path
            End If
        Catch ex As Exception
            MessageBox.Show("Close Application")
        End Try
    End Sub

    Private Sub BtnAddServer_Click(sender As Object, e As EventArgs) Handles BtnAddServer.Click
        If txtServerInput.Text Is String.Empty Then
            MessageBox.Show("Please type in Server Name to Add Server")
        Else
            ListBox1.Items.Add(txtServerInput.Text)
        End If
    End Sub

    Private Sub BtnRemoveServer_Click(sender As Object, e As EventArgs) Handles BtnRemoveServer.Click
        If ListBox1.SelectedIndex > -1 Then
            ListBox1.Items.RemoveAt(ListBox1.SelectedIndex)
        ElseIf txtServerInput.Text IsNot String.Empty Then
            ListBox1.Items.Remove(txtServerInput.Text)
        Else
            MessageBox.Show("Please type in Server Name to Remove Server")
        End If
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles BtnExit.Click
        Close()
    End Sub

    Private Sub BtnReadConfigFile_Click(sender As Object, e As EventArgs) Handles BtnReadConfigFile.Click

        Try
            Dim lines() As String = IO.File.ReadAllLines(txtReadConfigFile.Text)
            ListBox1.Items.AddRange(lines)

        Catch ex As Exception
            MessageBox.Show("Path does not exist or extension is not added at the end of the filename")
        End Try
    End Sub

    Private Sub BtnClearText_Click(sender As Object, e As EventArgs) Handles BtnClearText.Click
        ListBox1.Items.Clear()
        txtReadConfigFile.Clear()
        txtServerInput.Clear()
        txtDeleteFile.Clear()
        MessageBox.Show("Text cleared.")
        txtReadConfigFile.Text = "C:\ScanChart\uspiservers.txt"
    End Sub

    Private Sub BtnCreateConfigFile_Click(sender As Object, e As EventArgs) Handles BtnCreateConfigFile.Click
        Try

            Dim path As String = txtCreateConfigFile.Text

            Dim arrayItems() As String
            ReDim arrayItems(ListBox1.Items.Count() - 1)
            If File.Exists(path) Then
                File.Delete(path)
            End If
            For i = 1 To ListBox1.Items.Count()
                arrayItems(i - 1) = ListBox1.Items(i - 1).ToString()
                File.AppendAllText(path, arrayItems(i - 1).ToString() + vbNewLine)

            Next i

            MessageBox.Show("File has been created")
        Catch ex As Exception
            MessageBox.Show("File not created")
        End Try

    End Sub

    Private Sub BtnDeleteConfigFile_Click(sender As Object, e As EventArgs) Handles BtnDeleteConfigFile.Click
        Try
            Dim path As String = txtDeleteFile.Text
            File.Delete(path)
            MessageBox.Show("File " + txtDeleteFile.Text + " has been removed")
        Catch ex As Exception
            MessageBox.Show(txtDeleteFile.Text + " Path does not exist")
        End Try
    End Sub
End Class
